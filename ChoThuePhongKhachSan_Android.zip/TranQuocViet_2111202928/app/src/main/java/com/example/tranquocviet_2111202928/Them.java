package com.example.tranquocviet_2111202928;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class Them extends AppCompatActivity {
    EditText name,soPhong,soNgay,donGia;
    Button them,back;
    MyDBHelper dbHelper = new MyDBHelper(this);
    @Override
    protected void onStop() {
        super.onStop();
        dbHelper.closeDB();
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_them);
        name = findViewById(R.id.edtHoTen);
        soPhong=findViewById(R.id.edt_SoPhong);
        soNgay=findViewById(R.id.edtSoNgayLuuTru);
        donGia=findViewById(R.id.edtDonGia);
        them=findViewById(R.id.btn_Sua);
        back=findViewById(R.id.btn_Back);


        them.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(name.getText() != null && soPhong.getText() != null && soNgay.getText() != null && donGia.getText() != null ){
                    long result = dbHelper.Insert(name.getText().toString(), soPhong.getText().toString(), Integer.parseInt(soNgay.getText().toString()), Integer.parseInt(donGia.getText().toString()));
                    if (result != -1) {
                        Toast.makeText(Them.this, "Thêm thành công!", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(Them.this, "Thêm thất bại!", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent resultIntent = new Intent();
                setResult(Activity.RESULT_OK, resultIntent);
                finish();
            }
        });
    }
}