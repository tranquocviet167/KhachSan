package com.example.tranquocviet_2111202928;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;

public class MainActivity extends AppCompatActivity {
    EditText search;
    ListView listView;
    ImageView menu, add;

    MyDBHelper dbHelper = new MyDBHelper(this);
    List<KhachHang> listKhachHang = new ArrayList<>();
    KhachHangAdapter adapter;

    @Override
    protected void onStop() {
        super.onStop();
        dbHelper.closeDB();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        search = findViewById(R.id.edtSearch);
        menu = findViewById(R.id.btn_menu);
        add = findViewById(R.id.btn_add);
        listView = findViewById(R.id.lv);
        add();
        menu();
        registerForContextMenu(listView);
        DisplayAll();
        setupSearch();
    }

    private void DisplayAll() {
        Cursor cursor = dbHelper.getAll();
        if (cursor != null) {
            while (cursor.moveToNext()) {
                int id = cursor.getInt(cursor.getColumnIndex(MyDBHelper.getID()));
                String name = cursor.getString(cursor.getColumnIndex(MyDBHelper.getNAME()));
                String soPhong = cursor.getString(cursor.getColumnIndex(MyDBHelper.getSOPHONG()));
                int soNgay = cursor.getInt(cursor.getColumnIndex(MyDBHelper.SONGAY()));
                int donGia = cursor.getInt(cursor.getColumnIndex(MyDBHelper.getDONGIA()));

                listKhachHang.add(new KhachHang(id, name, soPhong, soNgay, donGia));
            }

            adapter = new KhachHangAdapter(this, R.layout.item, listKhachHang);
            listView.setAdapter(adapter);
        }
    }

    private void add() {
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent_add = new Intent(MainActivity.this, Them.class);
                startActivityForResult(intent_add, 1);
            }
        });
    }

    private void menu() {
        menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PopupMenu popupMenu = new PopupMenu(MainActivity.this, v);
                popupMenu.getMenuInflater().inflate(R.layout.menu, popupMenu.getMenu());
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        CharSequence charSequence = Objects.requireNonNull(item.getTitle());
                        if (charSequence.equals("Tiền giảm dần")) {
                            Comparator<KhachHang> comparator = new Comparator<KhachHang>() {
                                @Override
                                public int compare(KhachHang khachHang1, KhachHang khachHang2) {
                                    return Integer.compare(khachHang2.getTongTien(), khachHang1.getTongTien());
                                }
                            };
                            Collections.sort(listKhachHang, comparator);
                            adapter.notifyDataSetChanged();
                        }
                        return false;
                    }
                });
                popupMenu.show();
            }
        });
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) menuInfo;
        int position = info.position;

        menu.setHeaderTitle("Choose an action");
        menu.add(Menu.NONE, 1, Menu.NONE, "Sửa");
        menu.add(Menu.NONE, 2, Menu.NONE, "Xóa");
        menu.add(Menu.NONE, 3, Menu.NONE, "Tìm kiếm");
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        int position = info.position;

        switch (item.getItemId()) {
            case 1:
                Intent intent = new Intent(MainActivity.this, Sua.class);
                intent.putExtra("KhachHang", listKhachHang.get(position));
                startActivityForResult(intent, 1);
                break;
            case 2:
                showdialog_delete(position);
                break;
            case 3:
                displayCustomerInfo(position);
                break;
        }
        return super.onContextItemSelected(item);
    }

    private void displayCustomerInfo(int position) {
        KhachHang khachHang = listKhachHang.get(position);
        String message = "Khách hàng: " + khachHang.getHoTen() + "\n" +
                "Số phòng: " + khachHang.getSoPhong() + "\n" +
                "Số ngày lưu trú: " + khachHang.getSoNgay() + "\n" +
                "Đơn giá: " + khachHang.getDonGia() + "\n" +
                "Tổng tiền: " + khachHang.getTongTien();
        Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show();
    }

    private void showdialog_delete(final int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Xác nhận xóa");
        builder.setMessage("Bạn có chắc chắn muốn xóa khách hàng này?");
        builder.setPositiveButton("Có", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dbHelper.Delete(listKhachHang.get(position).getId());
                listKhachHang.remove(position);
                adapter.notifyDataSetChanged();
                Toast.makeText(MainActivity.this, "Đã xóa khách hàng", Toast.LENGTH_SHORT).show();
            }
        });
        builder.setNegativeButton("Không", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        builder.show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1) {
            if (resultCode == Activity.RESULT_OK) {
                dbHelper.openDB();
                listKhachHang.clear();
                DisplayAll();
            }
        }
    }
//sự kiện khi nhập số tiền vào edtSearch và listview chỉ hiển thị
    //thông tin của các khách hàng có số tiền lớn hơn số tiền mà ta nhập vào
    private void setupSearch() {
        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                // Không cần hành động trước khi văn bản thay đổi
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                filterList(charSequence.toString());
            }

            @Override
            public void afterTextChanged(Editable editable) {
                // Không cần hành động sau khi văn bản thay đổi
            }
        });
    }

    private void filterList(String searchText) {
        if (searchText.isEmpty()) {
            adapter.updateList(listKhachHang);
            return;
        }

        int searchAmount;
        try {
            searchAmount = Integer.parseInt(searchText);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Vui lòng nhập một số hợp lệ", Toast.LENGTH_SHORT).show();
            return;
        }

        List<KhachHang> filteredList = new ArrayList<>();
        for (KhachHang khachHang : listKhachHang) {
            if (khachHang.getTongTien() > searchAmount) {
                filteredList.add(khachHang);
            }
        }

        adapter.updateList(filteredList);
    }
}