package com.example.tranquocviet_2111202928;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class KhachHangAdapter extends ArrayAdapter<KhachHang> {
    private List<KhachHang> listKhachHang;

    public KhachHangAdapter(@NonNull Context context, int resource, @NonNull List<KhachHang> objects) {
        super(context, resource, objects);
        this.listKhachHang = objects;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View v = convertView;
        if (v == null) {
            LayoutInflater vi = LayoutInflater.from(getContext());
            v = View.inflate(getContext(), R.layout.item, null);
        }
        KhachHang khachHang = getItem(position);
        if (khachHang != null) {
            TextView txtTen = v.findViewById(R.id.txtTen);
            TextView txtSoPhong = v.findViewById(R.id.txtSoPhong);
            TextView txtTongTien = v.findViewById(R.id.txtTongTien);
            txtTen.setText(khachHang.getHoTen());
            txtSoPhong.setText(khachHang.getSoPhong());
            txtTongTien.setText(String.valueOf(khachHang.getTongTien()));
        }
        return v;
    }
//sự kiện load lại listview khi nhập số tiền
    public void updateList(List<KhachHang> newList) {
        listKhachHang.clear();
        listKhachHang.addAll(newList);
        notifyDataSetChanged();
    }
}
