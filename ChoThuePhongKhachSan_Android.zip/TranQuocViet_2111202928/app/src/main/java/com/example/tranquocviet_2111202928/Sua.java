package com.example.tranquocviet_2111202928;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Sua extends AppCompatActivity {
    EditText name,soPhong,donGia,soNgay;
    Button sua,back;

    MyDBHelper dbHelper = new MyDBHelper(this);

    @Override
    protected void onStop() {
        super.onStop();
        dbHelper.closeDB();
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sua);
        Intent intent = getIntent();
        KhachHang khachHang = (KhachHang) intent.getSerializableExtra("KhachHang");
        name = findViewById(R.id.edtHoTen);
        soPhong=findViewById(R.id.edt_SoPhong);
        soNgay=findViewById(R.id.edtSoNgayLuuTru);
        donGia=findViewById(R.id.edtDonGia);



        name.setText(khachHang.getHoTen());
        soPhong.setText(khachHang.getSoPhong());
        donGia.setText(String.valueOf(khachHang.getDonGia()));
        soNgay.setText(String.valueOf(khachHang.getSoNgay()));

        sua=findViewById(R.id.btn_Sua);
        back=findViewById(R.id.btn_Back);
        sua.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (name.getText() != null && soPhong.getText() != null && soNgay.getText() != null && donGia.getText() != null) {
                    long result = dbHelper.Update(khachHang.getId(),name.getText().toString(), soPhong.getText().toString(),  Integer.parseInt(soNgay.getText().toString()), Integer.parseInt(donGia.getText().toString()));
                    if (result != -1) {
                        Toast.makeText(Sua.this, "Sửa thành công!", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(Sua.this, "Sửa thất bại!", Toast.LENGTH_SHORT).show();
                    }
                }

        }
                               });

                back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent resultIntent = new Intent();
                setResult(Activity.RESULT_OK, resultIntent);
                finish();
            }
        });
    }
}