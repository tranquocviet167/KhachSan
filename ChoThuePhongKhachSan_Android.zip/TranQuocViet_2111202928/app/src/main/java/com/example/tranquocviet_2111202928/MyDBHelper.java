package com.example.tranquocviet_2111202928;

import android.app.DownloadManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.preference.PreferenceManager;
public class MyDBHelper extends SQLiteOpenHelper{
    public static final String DATABASE_NAME="Sqlite_09";
    public static final int DATABASE_VERSION = 1;
    public static final String TABLE_NAME = "KhachHang";
    public static final String ID="id";
    public static final String NAME="HoTen";
    public static final String SOPHONG="SoPhong";
    public static final String DONGIA="DonGia";

    public static final String SONGAY="SoNGay";
    public static final String TONGTIEN="TongTien";
    private SQLiteDatabase myDB;
    private Context context;

    public MyDBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.context = context;
    }
    public static String getID(){return ID;}
    public static String getNAME(){return NAME;}
    public static String getSOPHONG(){return SOPHONG;}
    public static String getDONGIA(){return DONGIA;}
    public static String SONGAY(){return SONGAY;}

    public void onCreate(SQLiteDatabase db) {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        boolean isDatabaseCreated = sharedPreferences.getBoolean("isDatabaseCreated", false);
        if (!isDatabaseCreated) {
            String queryTable = "CREATE TABLE " + TABLE_NAME +
                    " ( " + ID + " INTEGER PRIMARY KEY autoincrement," +
                    NAME + " TEXT NOT NULL, " +
                    SOPHONG+ " TEXT NOT NULL, " +
                    SONGAY + " INT NOT NULL, " +
                    DONGIA + " INT NOT NULL )" ;
            db.execSQL(queryTable);
            String[][] dulieumau={
                    {"Tran Quoc Viet","B204","365","2500"},
                    {"Tran Quoc Viet2","B204","31","250"},
                    {"Tran Quoc Viet3","B204","52","25"},
                    {"Tran Quoc Viet4","B204","3","25"},
                    {"Tran Quoc Viet5","B204","35","2520"},
                    {"Tran Quoc Viet6","B204","365","2456"},
                    {"Tran Quoc Tuan6","B204","365","2456"},
            };
            for (String[] khachhang : dulieumau) {
                String insertQuery = "INSERT INTO " + TABLE_NAME + " (" + NAME + ", " + SOPHONG + ", " + SONGAY + ", " + DONGIA + ") VALUES ('" + khachhang[0] + "', '" + khachhang[1] + "', '" + khachhang[2] + "', '" + khachhang[3] +   "')";
                db.execSQL(insertQuery);
            }
        }
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    }
    public void openDB() {
        myDB = getWritableDatabase();
    }
    public void closeDB() {
        if (myDB != null && myDB.isOpen()) {
            myDB.close();
        }
    }
    public long Insert(String name, String sophong, int songay,int dongia) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(NAME, name);
        values.put(SOPHONG, sophong);
        values.put(SONGAY, songay);
        values.put(DONGIA, dongia);

        return db.insert(TABLE_NAME, null, values);
    }
    public Cursor getAll() {
        SQLiteDatabase db = getReadableDatabase();
        return db.query(TABLE_NAME, null, null, null, null, null,null);
    }
    public long Update(int Id, String name, String sophong, int songay,int dongia) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(NAME, name);
        values.put(SOPHONG, sophong);
        values.put(SONGAY, songay);
        values.put(DONGIA, dongia);
        return db.update(TABLE_NAME, values, ID + " = ?", new String[]{String.valueOf(Id)});
    }
    public long Delete(int Id) {
        SQLiteDatabase db = getWritableDatabase();
        return db.delete(TABLE_NAME, ID + " = ?", new String[]{String.valueOf(Id)});
    }




}
