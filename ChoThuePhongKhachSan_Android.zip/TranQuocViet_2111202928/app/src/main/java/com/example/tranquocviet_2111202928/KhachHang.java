package com.example.tranquocviet_2111202928;

import java.io.Serializable;

public class KhachHang implements Serializable {
    private int Id;
    private String HoTen;
    private String SoPhong;
    private int SoNgay;
    private int DonGia;

    public KhachHang(int Id, String hoTen, String soPhong, int soNgay, int donGia) {
        this.Id = Id;
        HoTen = hoTen;
        SoNgay = soNgay;
        SoPhong = soPhong;
        DonGia = donGia;
    }

    public int getId() { return Id; }

    public String getHoTen() { return HoTen; }

    public String getSoPhong() { return SoPhong; }

    public int getSoNgay() { return SoNgay; }

    public int getDonGia() { return DonGia; }

    public void setId(int id) { Id = id; }

    public void setHoTen(String hoTen) { HoTen = hoTen; }

    public void setSoPhong(String soPhong) { SoPhong = soPhong; } // Sửa lại kiểu dữ liệu của tham số

    public void setSoNgay(int soNgay) { SoNgay = soNgay; }

    public void setDonGia(int donGia) { DonGia = donGia; }

    public int getTongTien() { return SoNgay * DonGia; }
}
